// WinScraper.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "WinScraper.h"
#include "windowfinder.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif



// CWinScraperApp

BEGIN_MESSAGE_MAP(CWinScraperApp, CWinApp)
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()






// CWinScraperApp construction

CWinScraperApp::CWinScraperApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CWinScraperApp object

CWinScraperApp theApp;


// CWinScraperApp initialization

BOOL CWinScraperApp::InitInstance()
{
	// InitCommonControls() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	InitCommonControls();

	CWinApp::InitInstance();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Data Perceptions"));


	InitialiseResources();
    long lRet = (long)DialogBox
        (
        (HINSTANCE)m_hInstance, // handle to application instance 
        (LPCTSTR)MAKEINTRESOURCE
            (IDD_DIALOG_SEARCH_WINDOW), // identifies dialog box template 
        (HWND)NULL, // handle to owner window 
        (DLGPROC)SearchWindowDialogProc // pointer to dialog box procedure 
        );



	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return lRet;
}
