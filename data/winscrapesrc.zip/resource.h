//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WinScraper.rc
//
#define IDC_CURSOR_SEARCH_WINDOW        101
#define IDD_DIALOG_SEARCH_WINDOW        103
#define IDB_BITMAP_FINDER_EMPTY         106
#define IDB_BITMAP_FINDER_FILLED        107
#define IDR_MAINFRAME                   128
#define IDC_EDIT_STATUS                 1002
#define IDC_STATIC_ICON_FINDER_TOOL     1003
#define IDC_WINDOWTEXT_EDIT             1004
#define IDC_CLIPPIE_BUTTON              1005
#define IDC_XPOS_EDIT                   1006
#define IDC_YPOS_EDIT                   1007
#define IDC_MOVETO_BUTTON               1008
#define IDC_WIDTH_EDIT                  1009
#define IDC_HEIGHT_EDIT                 1010
#define IDC_RESIZE_BUTTON               1011
#define IDC_TOPMOST_CHECK               1012
#define IDC_EXPANDVIEW_CHECK            1014
#define IDC_DETAILS_STATIC              1015
#define IDC_WINTXT_STATIC               1016
#define IDC_CAPTURE_BUTTON              1017
#define IDC_LINK_STATIC                 1018
#define IDC_CAPTURE_BUTTON2             1019
#define IDC_CENTER_BUTTON               1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           1119
#endif
#endif
